package com.example.PatientManagement2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientManagement2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
