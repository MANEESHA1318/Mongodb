package com.example.PatientManagement2.controller;

import java.util.List;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.PatientManagement2.model.Patient;
import com.example.PatientManagement2.repo.PatientRepository;
import com.example.PatientManagement2.service.PatientService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {
	@Autowired
	private PatientService patientService;

	@PostMapping("/generate")
	public ResponseEntity<String> generatePatients(@RequestParam int count) {
	patientService.generatePatients(count);
	return ResponseEntity.ok().body("Successfully generated " + count + " patients.");
	}

	@GetMapping("/get")
	public List<Patient> getAllPatients() {
	return patientService.getAllPatients();
	}
	private final PatientRepository patientRepository;

	public PatientController(PatientRepository patientRepository) {
	this.patientRepository = patientRepository;
	}

@GetMapping("/{id}")
public ResponseEntity<java.util.Optional<Patient>> getRecordById(@PathVariable String id) {
	java.util.Optional<Patient> entity = patientRepository.findById(id);
if (entity != null) {
return ResponseEntity.ok(entity);
} else {
return ResponseEntity.notFound().build();
}
}
@PutMapping("/{id}")
public Patient updatePatient(@PathVariable String id, @RequestBody Patient updatedPatient) throws AttributeNotFoundException {
Patient patient = patientRepository.findById(id).orElseThrow(() -> new AttributeNotFoundException("MyClass not found with id: " + id));

// Update the fields
patient.setName(updatedPatient.getName());
patient.setAge(updatedPatient.getAge());
patient.setAddresses(updatedPatient.getAddresses());
//patient.setStreet(updatedPatient.getStreet());
patient.setBillings(updatedPatient.getBillings());
patient.setLabTests(updatedPatient.getLabTests());
patient.setOpVisits(updatedPatient.getOpVisits());

return patientRepository.save(patient);
}



@DeleteMapping("/{id}")
public ResponseEntity<String> deleteRecord(@PathVariable("id") String id) {
if (patientRepository.existsById(id)) {
patientRepository.deleteById(id);
return ResponseEntity.ok("Record deleted successfully");
} else {
return ResponseEntity.notFound().build();
}
}

}










