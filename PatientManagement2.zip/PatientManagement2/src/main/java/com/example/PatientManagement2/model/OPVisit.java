package com.example.PatientManagement2.model;

//import java.sql.Date;

public class OPVisit {
	//private Date date;
	private String doctorName;
	private String description;
	
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setDate(java.util.Date between) {
		// TODO Auto-generated method stub
		
	}

}
