package com.example.PatientManagement2.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "collection")
public class Patient {
		@Id
		private String id;
		private String name;
		private int age;
		private List<Address> addresses;
		private List<Billing> billings;
		private List<LabTest> labTests;
		private List<OPVisit> opVisits;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public List<Address> getAddresses() {
			return addresses;
		}
		public void setAddresses(List<Address> addresses) {
			this.addresses = addresses;
		}
		public List<Billing> getBillings() {
			return billings;
		}
		public void setBillings(List<Billing> billings) {
			this.billings = billings;
		}
		public List<LabTest> getLabTests() {
			return labTests;
		}
		public void setLabTests(List<LabTest> labTests) {
			this.labTests = labTests;
		}
		public List<OPVisit> getOpVisits() {
			return opVisits;
		}
		public void setOpVisits(List<OPVisit> opVisits) {
			this.opVisits = opVisits;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}


}



